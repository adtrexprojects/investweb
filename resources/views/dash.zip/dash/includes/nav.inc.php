<?php


include_once('includes/dbConnection.php');

$sn=$_SESSION['id_db'];
$sql_sort=mysqli_query($conn, "SELECT * FROM user_data WHERE sn='$sn'");
$row=mysqli_fetch_assoc($sql_sort);

$title = $row["title"];
$surname = $row["surname"];
$firstname = $row["firstname"];
$user_id = $row["user_id"];
$payment_status = $row["payment_status"];
$residential = $row["residential"];

?>
<div class="text-center logo-main logo-main-2" ><img width="230" height="56" src="../images/logo.png"></div>

<nav class="navbar navbar-light text-center ">
  <div class="container-fluid">
    <div class="row header">
      
       <i style="margin-top: 7px; margin-right: 20px; float: right; width: 20px; cursor:pointer" onclick="openNav()" class="fa fa-bars"></i>
       
      
      <div class="col search-box head-left nav-top-content" > 
        <span class="search-icon nav-top-content">
          <i style="color: grey;" class="fas fa-search">
          </i>
        </span>
        <input class="search nav-top-content" type="search" placeholder="Search" name=""></div>
        <i style="margin-top: 7px; margin-right: 20px; float: right; width: 20px; font-size: 20px;" class="fas fa-user-circle">
          <span class="nav-hover">
          <?php 
          echo $title."  ". $surname."  ". $firstname." <br> ";
          if ($payment_status == "unverified") {
          }
          else {
          echo $user_id;
          }
          
           ?>
        </span></i>
       
        
       <i style="margin-top: 7px;  float: right; width: 20px; font-size: 20px;" class="far fa-bell">
        <span class="nav-hover">
          <p>Notifications</p>
          
            <?php 
          
          if ($residential == NULL) {
            echo'<a href="residential.php"  style="text-decoration:none;">
            <div  class="notification"> 
             click here to fill in your residential address
            </div></a>';
          }
          else {
          
          }
          
           ?>
           
          
           
        </span>
      </i> 
      <span id="no1">
        <?php
        if ($residential == NULL) {
            echo "1";
          }
          else {
            echo'0';
          }?>
          </span>


      
    </div>
  </div>
  <script>
    
  </script>
</nav>