<?php

session_start(); // start session

//START User Verification



include_once('includes/dbConnection.php');

$sn=$_SESSION['logDin_user_email'];
$sql_sort=mysqli_query($conn, "SELECT * FROM user_data WHERE email='$sn'");
$row=mysqli_fetch_assoc($sql_sort);

$title = $row["title"];
$surname = $row["surname"];
$firstname = $row["firstname"];
$user_id = $row["user_id"];
$payment_status = $row["payment_status"];

?>

<?php
    //Include main NAV
    include_once 'includes/head.inc.php';


     
  ?>


  <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" style="color: grey;" class="closebtn" onclick="closeNav()">&times;</a>

  <a href="index.php" ><p class="dash-active"><i style="color: #99C24D;" class="fas fa-home"></i>Dashboard</p></a>
  <a href="profile.php" style="color: black"><p class="dash-menu-text"><i  class="fas fa-user-circle"></i>Profile</p></a>
  <a href="#" style="color: black"><p class="dash-menu-text"><i class="fas fa-shopping-cart"></i>Shopping</p></a>
  <a href="settings.php" style="color: black"><p class="dash-menu-text" ><i class="fas fa-cog" ></i>Settings</p></a>
  <a href="logout.php" style="color: black"><p class="dash-menu-text" ><i class="fas fa-arrow-right"></i>Logout</p></a>
</div>

    <div class="sidebar">
      <div class="text-center logo-main logo-main-1" style="background-color: #fff"><img width="230" height="56" src="../images/logo.png"></div>



      <center>
      
    <div class="menu-bar" >
  <a href="index.php" ><p class="dash-active"><i style="color: #99C24D;" class="fas fa-home"></i>Dashboard</p></a>
  <a href="profile.php" style="color: black"><p class="dash-menu-text"><i  class="fas fa-user-circle"></i>Profile</p></a>
  <a href="#" style="color: black"><p class="dash-menu-text"><i class="fas fa-shopping-cart"></i>Shopping</p></a>
  <a href="settings.php" style="color: black"><p class="dash-menu-text" ><i class="fas fa-cog" ></i>Settings</p></a>
  <a href="logout.php" style="color: black"><p class="dash-menu-text" ><i class="fas fa-arrow-right"></i>Logout</p></a>
  
</div>

  
</center>
</div>



<div class="main">

   <?php

               

                include_once 'includes/accountverify.php';
 ?>


  <?php
    //Include main NAV
    include_once 'includes/nav.inc.php';
  ?>


<div class="content text-center">
  <div class="container">
  <div class="row">
    <div class="box-pro">
      <h3>Profile Complete</h3>
      <div class="circle-bord circle-bord-percent"><p>40%</p></div>
      <button>Complete</button>
    </div>
    <div class="box-pro">
      <h3>Transaction History</h3>
      <div class="circle-bord"><p>0</p></div>
      <button> <i class="fas fa-info-circle"></i></i> More Info</button>
    </div>
    <div class="box-pro">
      <h3>Order History</h3>
      <div class="circle-bord"><p>0</p></div>
      <button><i class="fas fa-info-circle"></i> More Info</button>
    </div>
  </div>
</div>
    
  

  <div class="recent-events">
    <center>
    <h3>Events</h3>
    <hr>
  </center>
</div>

    
 </div>



<?php
    //Include main NAV
    include_once 'includes/footer.inc.php';
  ?>