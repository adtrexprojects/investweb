 <div class="sidebar">
      <div class="text-center logo-main logo-main-1"><img width="230" height="44" src="logo_dark.png"></div>
      <center>
      <div class="pro-pic">
        <img class="img-test"  width="20" height="20" src="https://res.cloudinary.com/de8awjxjn/image/upload/v1599081548/dum.jpg">
      <p>User</p>
      </div>
    <div class="menu-bar" >
  <p class="dash-active"><i style="color: #99C24D;" class="fas fa-home"></i>Dashboard</p>
  <p class="dash-menu-text"><i class="fas fa-user-circle"></i>Profile</p>
  <p class="dash-menu-text"><i class="fas fa-shopping-cart"></i>Shopping</p>
  <p class="dash-menu-text"><i class="fas fa-cog"></i>Settings</p>
</div>
  <div class="logout-btn"><i style="color: #99C24D;" class="fas fa-arrow-right"></i>Logout</div>
</center>
</div>